﻿namespace Dragonfly.Core.Security
{
    public interface IOtpSender
    {
    }
}
