﻿using Dragonfly.Core.Configuration;

namespace Dragonfly.Core.Security
{
    public interface ISecurityEnvironment : IApplicationEnvironment
    {
    }
}
