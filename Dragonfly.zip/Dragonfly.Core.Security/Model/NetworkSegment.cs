﻿namespace Dragonfly.Core.Security
{
    public class NetworkSegment
    {
        public int NetworkSegmentId { get; set; }
        public string StartAddress { get; set; }
        public string StopAddress { get; set; }
    }
}
