﻿namespace Dragonfly.Core.Security
{
    public enum PermissionType
    {
        Allow = 0,
        Deny = 1
    }
}
