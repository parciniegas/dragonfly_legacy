﻿namespace Dragonfly.Core.Security
{
    public enum EnabledState
    {
        EnabledForever,
        EnabledUntil,
        DisabledForever,
        DisabledUntil
    }
}
