﻿namespace Dragonfly.Core.Security
{
    public enum OtpSendMode
    {
        None = 0,
        Sms = 1,
        Email = 2
    }
}
