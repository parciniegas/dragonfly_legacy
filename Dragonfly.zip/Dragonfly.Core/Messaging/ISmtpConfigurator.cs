﻿namespace Dragonfly.Core.Messaging
{
    public interface ISmtpConfigurator
    {
        SmtpParams GetParams();
    }
}
