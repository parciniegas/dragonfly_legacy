﻿namespace Dragonfly.Core.Formatters
{
    public interface IStringFormatter
    {
        string Format(string input, string formatPattern);
    }
}
