﻿namespace Dragonfly.Core.Configuration
{
    public interface IConfigurator
    {
        string GetKey(string key);
    }
}
