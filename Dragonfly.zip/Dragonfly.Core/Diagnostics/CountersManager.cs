﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dragonfly.Core.Diagnostics
{
    public class CountersManager
    {
        #region Private Fields

        #endregion
    }
}
