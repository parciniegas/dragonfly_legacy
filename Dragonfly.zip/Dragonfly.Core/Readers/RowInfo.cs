﻿namespace Dragonfly.Core.Readers
{
    public class RowInfo
    {
        public long Number { get; set; }
        public string Row { get; set; }
        public bool IsHeader { get; set; }
    }
}
