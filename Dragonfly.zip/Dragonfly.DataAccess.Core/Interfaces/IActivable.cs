﻿namespace Dragonfly.DataAccess.Core
{
    interface IActivable
    {
    }
}
