﻿namespace Dragonfly.DataAccess.Core
{
    public interface ITracker
    {
        void TrackIt(ITrack track);
    }
}
