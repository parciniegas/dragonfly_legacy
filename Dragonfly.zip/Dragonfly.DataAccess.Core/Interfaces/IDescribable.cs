﻿namespace Dragonfly.DataAccess.Core
{
    public interface IDescribable
    {
        string Describe();
    }
}
