﻿namespace Dragonfly.DataAccess.Core
{
    public interface ITrackeable
    {
    }
}
