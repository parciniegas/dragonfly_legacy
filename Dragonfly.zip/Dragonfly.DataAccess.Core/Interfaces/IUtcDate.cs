﻿namespace Dragonfly.DataAccess.Core
{
    public interface IUtcDate
    {
         
    }
}