﻿namespace Dragonfly.DataAccess.Core
{
    public interface ICiphrable
    {
    }
}
