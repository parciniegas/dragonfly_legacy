﻿namespace Dragonfly.DataAccess.Core
{
    public interface ICacheable
    {
    }
}
