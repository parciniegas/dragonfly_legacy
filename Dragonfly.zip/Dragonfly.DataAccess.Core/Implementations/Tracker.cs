﻿namespace Dragonfly.DataAccess.Core
{
    public class Tracker : ITracker
    {
        public void TrackIt(ITrack track)
        {
            throw new System.NotImplementedException();
        }
    }
}
